<?php  
$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbname="reg";


$conn=mysqli_connect($host,$dbUsername,$dbPassword,$dbname);

if (isset($_POST["submit"])){
	$name=$_POST["name"];
	$gender=$_POST["gender"];
	$age=$_POST["age"];
	$uni=$_POST["uni"];


	$errorEmpty=false;
	

	if(empty($name) || empty($age)){
		echo"<span class='form-error'>Fill in all Fields</span>";
		$errorEmpty=true;
	}

	else{
		echo"<span class='form-success'>Welcome to our Family </span>";

		$query="insert into form(name,gender,age,uni) values('$name','$gender','$age','$uni')";
		$run=mysqli_query($conn,$query) or die('Error: ' . mysqli_error($conn));

	}

}
else{
	echo"There was an error!!!";
}


?>

<script>
	$("#fname, #age").removeClass("input-error");
	var errorEmpty="<?php echo $errorEmpty; ?>";
	


	if(errorEmpty==true){
		$("#fname, #age").addClass("input-error");

	}

	if(errorEmpty==false){
		$("#fname, #age").val("");
	}
</script>